public class Trabajador extends Persona{
	private int numeroPersonal;

	public int getNumeroPersonal(){
		return numeroPersonal;
	}

	public void setNumeroPersonal(int xnumeroPersonal){
		numeroPersonal = xnumeroPersonal;
	}

}